#!/usr/bin/env python3
"""Preflight network access, then run the complete configured DEX-first/CEX-second scan.

This is intended for a hosted runner (for example GitHub Actions). It is safe to
run in the cloud; it uses public/read-only market endpoints and never submits
orders. It deliberately stops early when every source is unreachable instead
of spending several minutes pacing requests that cannot succeed.
"""
import argparse
import json
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "scripts"
DEFAULT_VENUES = ("binance", "bybit", "okx", "mexc", "bitget", "gate", "kucoin")


def any_market_source_available(preflight):
    """True when at least one preflighted market endpoint returned data."""
    availability = preflight.get("market_availability") or {}
    if availability:
        return any(bool(availability.get(k)) for k in ("dex_discovery_ok", "aggregator_ok", "cex_spot_ok"))
    # Backward compatibility with older preflight output.
    return any(bool(row.get("market_ok")) for row in (preflight.get("summary") or {}).values())


def build_scan_command(args, outdir):
    venues = args.venue or list(DEFAULT_VENUES)
    cmd = [sys.executable, str(SCRIPTS / "rocket_hunt.py"),
           "--out", str(outdir / "rocket-hunt.json"),
           "--md", str(outdir / "rocket-hunt.md"),
           "--timeout", str(args.timeout),
           "--workers", str(args.workers),
           "--gecko-pages", str(args.gecko_pages),
           "--network-sweep-limit", str(args.network_sweep_limit),
           "--gecko-request-interval", str(args.gecko_request_interval),
           "--dex-search-limit", str(args.dex_search_limit),
           "--dex-lookup-limit", str(args.dex_lookup_limit),
           "--checkpoint-dir", str(outdir / "checkpoints")]
    for venue in venues:
        cmd += ["--venue", venue]
    if args.resume:
        cmd += ["--resume", "--resume-max-age-seconds", str(args.resume_max_age_seconds)]
    if args.birdeye:
        # Let the scanner write an explicit SKIPPED source row when the
        # optional key is absent, rather than hiding the requested lane.
        cmd.append("--birdeye")
    return cmd


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--outdir", default="rocket-run", help="directory for preflight, JSON/Markdown, logs and checkpoints")
    p.add_argument("--venue", action="append", choices=DEFAULT_VENUES, help="CEX spot venue; repeatable (default: all seven)")
    p.add_argument("--preflight-timeout", type=float, default=5.0, help="hard-bounded preflight timeout per endpoint")
    p.add_argument("--preflight-workers", type=int, default=16)
    p.add_argument("--timeout", type=int, default=8, help="per-request timeout for the full scan")
    p.add_argument("--workers", type=int, default=8)
    p.add_argument("--gecko-pages", type=int, default=3)
    p.add_argument("--network-sweep-limit", type=int, default=24)
    p.add_argument("--gecko-request-interval", type=float, default=6.2)
    p.add_argument("--dex-search-limit", type=int, default=12)
    p.add_argument("--dex-lookup-limit", type=int, default=160)
    p.add_argument("--resume", action="store_true", help="reuse successful checkpoint responses that are still fresh")
    p.add_argument("--resume-max-age-seconds", type=int, default=900)
    p.add_argument("--birdeye", action="store_true", help="enable Birdeye only when BIRDEYE_API_KEY is present")
    args = p.parse_args(argv)
    if not 1 <= args.gecko_pages <= 10:
        p.error("--gecko-pages must be between 1 and 10")
    if not 0 <= args.network_sweep_limit <= 24:
        p.error("--network-sweep-limit must be between 0 and 24")
    if args.preflight_timeout <= 0 or args.timeout <= 0 or args.workers <= 0 or args.preflight_workers <= 0:
        p.error("timeouts and worker counts must be positive")
    if args.gecko_request_interval < 0:
        p.error("--gecko-request-interval must be non-negative")
    if not 1 <= args.dex_search_limit <= 12 or args.dex_lookup_limit < 0:
        p.error("--dex-search-limit must be 1-12 and --dex-lookup-limit must be non-negative")

    outdir = Path(args.outdir).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    preflight_path = outdir / "preflight.json"
    pf_cmd = [sys.executable, str(SCRIPTS / "preflight.py"),
              "--timeout", str(args.preflight_timeout),
              "--workers", str(args.preflight_workers),
              "--json", "--out", str(preflight_path)]
    for venue in (args.venue or DEFAULT_VENUES):
        pf_cmd += ["--venue", venue]

    print("[1/2] Checking hosted-runner network access (read-only probes)...", flush=True)
    pf_result = subprocess.run(pf_cmd, cwd=str(ROOT), check=False)
    if not preflight_path.exists():
        print("Preflight did not create its report; refusing to start the long scan.", file=sys.stderr)
        return pf_result.returncode or 2
    try:
        preflight = json.loads(preflight_path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        print("Cannot parse preflight report: %s" % exc, file=sys.stderr)
        return 2

    if not any_market_source_available(preflight):
        print("NO MARKET DATA ENDPOINT IS REACHABLE. Full scan was not started. "
              "See %s for endpoint-level errors." % preflight_path, file=sys.stderr, flush=True)
        return 2

    print("[2/2] Running configured DEX-first discovery and seven-venue CEX pass. "
          "The GeckoTerminal pacing budget is about %.1f minutes before overhead." %
          (((args.gecko_pages * 4 + args.network_sweep_limit * 3) - 1) * args.gecko_request_interval / 60.0),
          flush=True)
    birdeye_key_present = bool(os.environ.get("BIRDEYE_API_KEY"))
    if args.birdeye and not birdeye_key_present:
        print("Birdeye requested but BIRDEYE_API_KEY is missing; Birdeye will be skipped and logged as unavailable.",
              file=sys.stderr, flush=True)
    scan_cmd = build_scan_command(args, outdir)
    scan_result = subprocess.run(scan_cmd, cwd=str(ROOT), check=False)
    if scan_result.returncode != 0:
        print("Scanner returned %s. Inspect coverage in %s and %s." %
              (scan_result.returncode, outdir / "rocket-hunt.json", outdir / "rocket-hunt.md"),
              file=sys.stderr, flush=True)
    return scan_result.returncode


if __name__ == "__main__":
    raise SystemExit(main())
