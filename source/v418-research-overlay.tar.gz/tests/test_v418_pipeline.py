import gzip
import json
import tempfile
import unittest
from datetime import datetime, timezone, timedelta
from pathlib import Path

from scripts.v418_pipeline import (
    age_classify, asset_age_hours, collect_rows, fingerprint_clusters,
    market_key, process_snapshot, read_jsonl_gz,
)


class V418QualityTests(unittest.TestCase):
    def test_under_24h_dex_mark_is_preserved_but_not_called_24h(self):
        row = {"market_type": "dex_pool", "age_hours": 3.5, "change_24h_pct": 1200.0, "risk_flags": []}
        status = age_classify(row, datetime(2026, 11, 5, tzinfo=timezone.utc))
        self.assertEqual(status, "INSUFFICIENT_24H_HISTORY")
        self.assertIsNone(row["change_24h_pct"])
        self.assertEqual(row["source_reported_change_24h_pct"], 1200.0)
        self.assertEqual(row["source_reported_change_during_available_pool_history_pct"], 1200.0)

    def test_unknown_dex_age_is_not_silently_comparable(self):
        row = {"market_type": "dex_pool", "change_24h_pct": 400, "risk_flags": []}
        status = age_classify(row, datetime(2026, 11, 5, tzinfo=timezone.utc))
        self.assertEqual(status, "UNKNOWN_POOL_AGE_NOT_COMPARABLE")
        self.assertIsNone(row["change_24h_pct"])
        self.assertEqual(row["source_reported_change_24h_pct"], 400)

    def test_24h_or_older_dex_is_comparable_source_reported(self):
        row = {"market_type": "dex_pool", "age_hours": 24.1, "change_24h_pct": 22.0}
        self.assertEqual(age_classify(row, datetime.now(timezone.utc)), "SOURCE_REPORTED_24H_POOL_AGE_GE_24H")
        self.assertEqual(row["change_24h_pct"], 22.0)

    def test_cex_24h_fields_are_not_pool_age_filtered(self):
        row = {"market_type": "cex_spot", "change_24h_pct": 10.0}
        self.assertEqual(age_classify(row, datetime.now(timezone.utc)), "EXCHANGE_OR_AGGREGATOR_24H_FIELD")
        self.assertEqual(row["change_24h_pct"], 10.0)

    def test_age_from_pool_created_at(self):
        row = {"market_type": "dex_pool", "pool_created_at": "2026-11-04T12:00:00Z"}
        self.assertAlmostEqual(asset_age_hours(row, datetime(2026, 11, 5, 0, 0, tzinfo=timezone.utc)), 12)

    def test_market_key_never_uses_ticker_alone(self):
        self.assertIsNone(market_key({"symbol": "ABC", "asset": "ABC"}))

    def test_market_key_supports_chain_contract_without_prebuilt_identity(self):
        key = market_key({"chain": "base", "contract_address": "0xabc", "pool_address": "0xpool", "market_type": "dex_pool", "source": "gecko"})
        self.assertEqual(key, "base|0xabc|0xpool|||dex_pool")

    def test_market_key_includes_pool_to_distinguish_markets(self):
        a = {"identity": "dex:base:0xabc", "pool_address": "0x1", "source": "gecko"}
        b = {"identity": "dex:base:0xabc", "pool_address": "0x2", "source": "gecko"}
        self.assertNotEqual(market_key(a), market_key(b))

    def test_fingerprint_group_is_flagged_but_not_removed(self):
        rows = []
        for i in range(3):
            rows.append({"identity": f"dex:base:0x{i}", "pool_address": f"pool{i}", "market_type": "dex_pool", "chain": "base", "source": "gecko:base:new_pools", "price_usd": 0.020995 * (1 + i * 0.0005), "liquidity_usd": 31_500_000 * (1 + i * 0.0005)})
        clusters = fingerprint_clusters(rows)
        self.assertEqual(len(clusters), 1)
        self.assertTrue(all(row.get("fingerprint_cluster_id") for row in rows))
        self.assertEqual(len(rows), 3)

    def test_memory_snapshot_and_idempotent_rerun(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); out = root / "out"; memory = root / "memory"; out.mkdir()
            main = {
                "skill_version": "4.15.3", "created_utc": "2026-11-05T00:00:00Z",
                "top_24h_gainers": [
                    {"identity": "dex:base:0xaaa", "market_type": "dex_pool", "chain": "base", "contract_address": "0xaaa", "pool_address": "0xpool", "asset": "A", "age_hours": 12, "change_24h_pct": 900, "price_usd": 1.0, "retrieved_utc": "2026-11-05T00:00:00Z", "source": "gecko"},
                    {"identity": "dex:base:0xbbb", "market_type": "dex_pool", "chain": "base", "contract_address": "0xbbb", "pool_address": "0xpool2", "asset": "B", "age_hours": 48, "change_24h_pct": 50, "price_usd": 2.0, "retrieved_utc": "2026-11-05T00:00:00Z", "source": "gecko"},
                ],
                "new_pools_under_24h": [], "source_status": [],
            }
            forward = {"skill_version": "4.15.3", "candidates": []}
            (out / "rocket-hunt.json").write_text(json.dumps(main))
            (out / "forward-24h-rocket.json").write_text(json.dumps(forward))
            (out / "rocket-hunt.md").write_text("## Top 24h gainers\n")
            s1 = process_snapshot(out / "rocket-hunt.json", out / "forward-24h-rocket.json", out, memory, "run-1")
            self.assertEqual(s1["retained_report_rows_deduplicated"], 2)
            self.assertEqual(s1["comparable_24h_gainers"], 1)
            self.assertEqual(s1["new_launch_discovery_leads"], 1)
            self.assertEqual(s1["forecast_snapshots_new"], 2)
            s2 = process_snapshot(out / "rocket-hunt.json", out / "forward-24h-rocket.json", out, memory, "run-1")
            self.assertEqual(s2["forecast_snapshots_new"], 0)
            records = read_jsonl_gz(next((memory / "forecasts").glob("*.jsonl.gz")))
            self.assertEqual(len(records), 2)
            j = json.loads((out / "rocket-hunt.json").read_text())
            self.assertEqual(j["core_runtime_version"], "4.15.3")
            self.assertEqual(j["pipeline_version"], "4.18.0")
            self.assertEqual(len(j["reported_top_24h_gainers_raw"]), 2)
            self.assertEqual(len(j["new_launch_discovery_board_v418"]), 1)

    def test_outcome_grading_waits_for_observation_at_or_after_horizon(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); out = root / "out"; memory = root / "memory"; out.mkdir()
            main = {"skill_version": "4.15.3", "created_utc": "2026-11-05T00:00:00Z", "top_24h_gainers": [
                {"identity": "dex:base:0xaaa", "market_type": "dex_pool", "chain": "base", "contract_address": "0xaaa", "pool_address": "pool1", "asset": "A", "age_hours": 48, "price_usd": 1, "retrieved_utc": "2026-11-05T00:00:00Z", "source": "gecko"}
            ]}
            (out / "rocket-hunt.json").write_text(json.dumps(main)); (out / "rocket-hunt.md").write_text("")
            process_snapshot(out / "rocket-hunt.json", None, out, memory, "run-1")
            main2 = {"skill_version": "4.15.3", "created_utc": "2026-11-05T01:30:00Z", "top_24h_gainers": [
                {"identity": "dex:base:0xaaa", "market_type": "dex_pool", "chain": "base", "contract_address": "0xaaa", "pool_address": "pool1", "asset": "A", "age_hours": 48.5, "price_usd": 1.5, "retrieved_utc": "2026-11-05T00:30:00Z", "source": "gecko"}
            ]}
            (out / "rocket-hunt.json").write_text(json.dumps(main2))
            process_snapshot(out / "rocket-hunt.json", None, out, memory, "run-2")
            outcomes = []
            for p in (memory / "outcomes").glob("*.jsonl.gz"): outcomes.extend(read_jsonl_gz(p))
            self.assertFalse([o for o in outcomes if o["horizon_hours"] == 1])

    def test_outcome_grading_uses_same_market_and_marks_not_fills(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); out = root / "out"; memory = root / "memory"; out.mkdir()
            main = {"skill_version": "4.15.3", "created_utc": "2026-11-05T00:00:00Z", "top_24h_gainers": [
                {"identity": "dex:base:0xaaa", "market_type": "dex_pool", "chain": "base", "contract_address": "0xaaa", "pool_address": "pool1", "asset": "A", "age_hours": 48, "change_24h_pct": 12, "price_usd": 1, "retrieved_utc": "2026-11-05T00:00:00Z", "source": "gecko"}
            ]}
            (out / "rocket-hunt.json").write_text(json.dumps(main)); (out / "rocket-hunt.md").write_text("")
            process_snapshot(out / "rocket-hunt.json", None, out, memory, "run-1")
            # Next observation is 5 hours later and has the exact same pool identity.
            main2 = {"skill_version": "4.15.3", "created_utc": "2026-11-05T05:00:00Z", "top_24h_gainers": [
                {"identity": "dex:base:0xaaa", "market_type": "dex_pool", "chain": "base", "contract_address": "0xaaa", "pool_address": "pool1", "asset": "A", "age_hours": 53, "change_24h_pct": 15, "price_usd": 1.2, "retrieved_utc": "2026-11-05T05:00:00Z", "source": "gecko"}
            ]}
            (out / "rocket-hunt.json").write_text(json.dumps(main2))
            summary = process_snapshot(out / "rocket-hunt.json", None, out, memory, "run-2")
            outcomes = []
            for p in (memory / "outcomes").glob("*.jsonl.gz"): outcomes.extend(read_jsonl_gz(p))
            one_hour = [o for o in outcomes if o["horizon_hours"] == 1]
            self.assertTrue(one_hour)
            self.assertEqual(one_hour[0]["status"], "OBSERVED_MARK_NOT_EXECUTABLE_FILL")
            self.assertAlmostEqual(one_hour[0]["mark_return_pct"], 20.0)
            self.assertEqual(one_hour[0]["fees_slippage_status"], "NOT_MODELED")


if __name__ == "__main__":
    unittest.main()
