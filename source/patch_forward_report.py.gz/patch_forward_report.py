from pathlib import Path

ROOT = Path.cwd()
script = ROOT / "scripts" / "forward_24h_report.py"
text = script.read_text(encoding="utf-8")

def replace_once(old: str, new: str, label: str) -> None:
    global text
    count = text.count(old)
    if count != 1:
        raise SystemExit(f"{label}: expected exactly one match, found {count}")
    text = text.replace(old, new, 1)

replace_once(
'''    parser.add_argument("--dex-limit", type=int, default=8)
''',
'''    parser.add_argument("--dex-limit", type=int, default=12)
''',
"expand DEX follow-up breadth")

# Some venue candle adapters legitimately return (None, URL) when the venue
# omits OHLCV. Normalize before len(candles) and all downstream processing.
replace_once(
'''    stats = candle_stats(candles, price) if candles and price else {}
''',
'''    # Venue adapters may return None rather than an empty list for missing OHLCV.
    # Normalize here so the report can continue with explicit missing evidence.
    candles = candles or []
    stats = candle_stats(candles, price) if candles and price else {}
''',
"normalize missing candle arrays")

replace_once(
'''        "pool_address": row.get("pool_address"), "pair_url": row.get("pair_url"),
''',
'''        "pool_address": row.get("pool_address"), "pair_address": row.get("pool_address"),
        "pair_url": row.get("pair_url"),
''',
"carry explicit pair address")

helper = '''\n\ndef enforce_required_trade_fields(top, market_meta, forecast_end=None):
    """Require a fresh DEX price, candle-backed TP and exact pool/pair address.

    Entry price is deliberately a fresh pool spot *reference*, not a promise of
    an executable fill. Router availability remains a separate verification.
    Return (pick, missing_fields); never fabricate a missing value.
    """
    if not isinstance(top, dict) or not top:
        return None, ["ranked DEX pick"]
    meta = market_meta if isinstance(market_meta, dict) else {}
    trade = top.get("trade_plan") if isinstance(top.get("trade_plan"), dict) else {}
    pair_address = str(top.get("pool_address") or meta.get("pool_address") or "").strip()
    entry_price = num(top.get("price"))
    take_profit = num(trade.get("single_take_profit"))
    if take_profit is None:
        take_profit = num(meta.get("target_price"))
    target_method = str(meta.get("target_price_source") or top.get("target_price_source") or "")
    missing = []
    if str(top.get("market_type") or "").lower() != "dex_pool":
        missing.append("DEX spot market")
    if not pair_address:
        missing.append("exact pool/pair address")
    if not str(top.get("contract_address") or meta.get("contract_address") or "").strip():
        missing.append("exact token contract/mint")
    if entry_price is None or entry_price <= 0:
        missing.append("positive current spot reference price")
    if top.get("data_fresh") is not True:
        missing.append("fresh price timestamp")
    if top.get("market_verified") is not True:
        missing.append("verified DEX market identity")
    if top.get("entry_decision") == "AVOID — HARD FAIL":
        missing.append("candidate has a hard safety/market failure")
    if int(meta.get("_candles_count") or 0) < 20:
        missing.append("at least 20 hourly candles")
    if take_profit is None or entry_price is None or take_profit <= entry_price:
        missing.append("candle-derived single take-profit above entry")
    if not target_method or target_method == "UNVERIFIED":
        missing.append("verified take-profit derivation method")
    if missing:
        return None, missing

    basis = "FRESH DEX POOL SPOT REFERENCE — NOT A FIRM ROUTER/FILL QUOTE"
    trade["entry_price"] = entry_price
    trade["single_take_profit"] = take_profit
    trade["pair_address"] = pair_address
    trade["entry_price_basis"] = basis
    trade["target_method"] = target_method
    if forecast_end:
        trade["time_stop_24h"] = forecast_end
    top["trade_plan"] = trade
    top["pair_address"] = pair_address
    top["pool_address"] = pair_address
    top["target_price"] = take_profit
    top["target_price_source"] = target_method
    top["entry_price_basis"] = basis
    return top, []

'''
replace_once(
'''\ndef render_markdown(doc, report):
''',
helper + '''\ndef render_markdown(doc, report):
''',
"insert mandatory trade plan validator")

replace_once(
'''    candidate = top.get("_market_metadata") or {}
    lines = ["## Forward 24-hour rocket forecast", "",
''',
'''    candidate = top.get("_market_metadata") or {}
    if not top:
        return "\\n".join([
            "## Forward 24-hour rocket forecast", "",
            "**Status: NO QUALIFYING TOP PICK**", "",
            "No candidate passed all mandatory evidence checks. This report intentionally does not publish an incomplete pick.",
            "A valid pick requires a fresh spot reference entry price, a candle-derived single take-profit above entry, and an exact DEX pool/pair address.",
            "The trailing raw 24h gainer board remains discovery-only and is not an entry recommendation.", "",
        ])
    lines = ["## Forward 24-hour rocket forecast", "",
''',
"prevent incomplete markdown pick")

replace_once(
'''             "| Pool / pair address (copy) | `%s` |" % (top.get("pool_address") or "N/A for CEX"),
''',
'''             "| Pair address (copy exactly) | `%s` |" % top.get("pair_address"),
''',
"make pair address explicit")

replace_once(
'''             "| Entry price | %s |" % (fmt(plan_entry) if plan_entry is not None else "UNVERIFIED — no verified route"),
             "| Single take-profit | %s |" % (fmt(target) if target is not None else "UNVERIFIED — OHLCV target unavailable"),
''',
'''             "| Entry price | %s |" % fmt(plan_entry),
             "| Entry price basis | %s |" % (trade.get("entry_price_basis") or "UNVERIFIED"),
             "| Single take-profit | %s |" % fmt(target),
''',
"render required numeric trade fields")

# Do not fabricate an incomplete fallback Top Rocket when the candle/price/address
# contract is not satisfied. The raw discovery boards are preserved separately.
old = '''            fallback_pool = [c for c in candidates if c.get("market_type") == "dex_pool" and
                             c.get("pool_address") and c.get("contract_address")]
            fallback_pool.sort(key=lambda c: (num((c.get("_scan_row") or {}).get("rank_score")) or 0,
                                              num((c.get("_scan_row") or {}).get("change_24h_pct")) or -1e9), reverse=True)
            fallback = fallback_pool[0] if fallback_pool else None
            top_pick = None
            if fallback:
                top_pick = {"asset": fallback.get("asset"), "pair": fallback.get("pair"),
                            "venue": fallback.get("venue"), "chain": fallback.get("chain"),
                            "market_type": "dex_pool", "identity": fallback.get("identity"),
                            "price": fallback.get("price"), "data_timestamp_utc": fallback.get("data_timestamp_utc"),
                            "pool_address": fallback.get("pool_address"), "contract_address": fallback.get("contract_address"),
                            "pair_url": fallback.get("pair_url"), "entry_decision": "TOP ROCKET — EXECUTION UNVERIFIED",
                            "entry_blockers": ["No sufficient fresh hourly OHLCV was available to derive a source-backed single take-profit.",
                                               "Fresh executable DEX buy AND sell router quotes are not verified."],
                            "risk_flags": ["Forward-24h selection is a heuristic, not a calibrated prediction."],
                            "forecast_score": None, "relative_confidence": "UNVERIFIED",
                            "trade_plan": {"entry_price": None, "single_take_profit": None, "time_stop_24h": forecast_end},
                            "target_price_source": "UNVERIFIED"}
            no_pick = {"schema": "crypto-prebreakout.forward-24h-rocket.v1", "status": "TOP_ROCKET_EXECUTION_UNVERIFIED" if top_pick else "NO_DEX_POOL_WITH_COPYABLE_IDENTITY",
'''
new = '''            # No incomplete Top Pick: missing required values are not replaced
            # with placeholders or estimates unsupported by the selected candles.
            top_pick = None
            no_pick = {"schema": "crypto-prebreakout.forward-24h-rocket.v1", "status": "NO_QUALIFYING_PICK_REQUIRED_FIELDS_NOT_VERIFIED",
'''
replace_once(old, new, "remove incomplete fallback top pick")

replace_once(
'''                       "reason": "No DEX candidate had all of: a copyable pool address, token contract, fresh price, at least 20 hourly OHLCV candles, and a single candle-derived target above current price.",
                       "raw_trailing_24h_champion": raw_top, "top_rocket_pick": top_pick,
                       "trade_plan": (top_pick or {}).get("trade_plan") or {"entry_price": None, "single_take_profit": None, "time_stop_24h": forecast_end},
''',
'''                       "reason": "No DEX candidate had all required fields: exact pair address, fresh spot reference entry price, at least 20 hourly candles and one candle-derived single take-profit above entry. No incomplete Top Pick was published.",
                       "required_fields": ["entry_price", "single_take_profit", "pair_address"],
                       "raw_trailing_24h_champion": raw_top, "top_rocket_pick": None,
''',
"record no-pick contract honestly")

# Replace the old conditional Top Pick markdown table with an explicit no-pick notice.
replace_once(
'''            if top_pick:
                lines += ["", "### Forward 24h Top Pick", "",
                          "**%s** — TOP ROCKET / EXECUTION UNVERIFIED" % top_pick.get("asset"), "",
                          "| Field | Value |", "|---|---|",
                          "| Current price (USD) | %s |" % (("$" + format(num(top_pick.get("price")), ".12g")) if num(top_pick.get("price")) is not None else "UNVERIFIED"),
                          "| Price source timestamp (UTC) | %s |" % (top_pick.get("data_timestamp_utc") or "UNVERIFIED"),
                          "| Pair | %s |" % (top_pick.get("pair") or "UNVERIFIED"),
                          "| Pool / pair address (copy) | `%s` |" % top_pick.get("pool_address"),
                          "| Token contract / mint (copy) | `%s` |" % top_pick.get("contract_address"),
                          "| Pair page | %s |" % (top_pick.get("pair_url") or "UNVERIFIED"),
                          "| Entry price | UNVERIFIED — no executable route |",
                          "| Single take-profit | UNVERIFIED — OHLCV target unavailable |",
                          "| Time stop (24h) | %s |" % forecast_end]
            lines += ["", "CEX discovery remains in the broad mover report. The final Top Rocket is DEX-only so the on-chain pool address and token contract are directly copyable."]
''',
'''            lines += ["", "### Forward 24h Top Pick", "",
                      "**NO QUALIFYING PICK — no complete three-field trade plan was supported by source data.**", "",
                      "Required fields: Entry price, Single take-profit, Pair address. The scanner will not invent any of them.",
                      "", "CEX discovery remains in the broad mover report. Any published Top Pick must be DEX-only with an exact on-chain pair address."]
''',
"remove incomplete markdown fallback table")

replace_once(
'''        top.update({"pool_address": top_meta.get("pool_address"), "pair_url": top_meta.get("pair_url"),
                    "data_timestamp_utc": top_meta.get("data_timestamp_utc"),
                    "target_price_source": top_meta.get("target_price_source"),
                    "target_price_note": top_meta.get("target_price_note")})
        doc["top_rocket_pick"] = top
''',
'''        top.update({"pool_address": top_meta.get("pool_address"),
                    "pair_address": top_meta.get("pool_address"), "pair_url": top_meta.get("pair_url"),
                    "data_timestamp_utc": top_meta.get("data_timestamp_utc"),
                    "target_price": top_meta.get("target_price"),
                    "target_price_source": top_meta.get("target_price_source"),
                    "target_price_note": top_meta.get("target_price_note")})
        top, missing_required = enforce_required_trade_fields(top, top_meta, doc.get("forecast_window_end_utc"))
        if top is None:
            doc["top_rocket_pick"] = None
            doc["status"] = "NO_QUALIFYING_PICK_REQUIRED_FIELDS_NOT_VERIFIED"
            doc["required_fields"] = ["entry_price", "single_take_profit", "pair_address"]
            doc["required_field_gaps"] = missing_required
        else:
            doc["top_rocket_pick"] = top
            doc["status"] = "TOP_ROCKET_REFERENCE_PLAN_READY"
            doc["required_fields"] = ["entry_price", "single_take_profit", "pair_address"]
            doc["required_field_gaps"] = []
''',
"enforce full field contract on ranked top pick")

# Fail with a full traceback in logs, rather than suppressing the line that failed.
replace_once(
'''    except Exception as exc:
        print("Forward 24h report failed: %s: %s" % (type(exc).__name__, exc), file=sys.stderr)
        return 2
''',
'''    except Exception as exc:
        import traceback
        traceback.print_exc()
        print("Forward 24h report failed: %s: %s" % (type(exc).__name__, exc), file=sys.stderr)
        return 2
''',
"emit traceback on future forward-report errors")

script.write_text(text, encoding="utf-8")
print(f"Patched {script}")
