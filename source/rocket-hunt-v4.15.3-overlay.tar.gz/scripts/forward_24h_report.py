#!/usr/bin/env python3
"""Build the scan-start-anchored forward-24h Top Rocket and single-TP report.

Research-only. It fetches OHLCV for shortlisted markets, derives one explicitly
labelled technical target, and feeds the timestamped data to next_day_forecast.
Missing execution/safety/CVD/derivatives data remains UNVERIFIED.
"""
import argparse
import json
import math
import os
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timezone, timedelta
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "scripts"
sys.path.insert(0, str(SCRIPTS))
import next_day_forecast  # noqa: E402
import venues  # noqa: E402

GECKO = "https://api.geckoterminal.com/api/v2"
GECKO_ALIASES = {"avalanche": "avax", "sui": "sui-network", "fantom": "ftm",
                 "cronos": "cro", "sei": "sei-network"}


def utc_now():
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def parse_dt(value):
    try:
        dt = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        return (dt.replace(tzinfo=timezone.utc) if dt.tzinfo is None else dt.astimezone(timezone.utc))
    except (TypeError, ValueError):
        return None


def num(value):
    try:
        x = float(value)
        return x if math.isfinite(x) else None
    except (TypeError, ValueError):
        return None


def get_json(url, timeout=10):
    req = urllib.request.Request(url, headers={"Accept": "application/json",
        "User-Agent": "crypto-prebreakout-forward-24h/4.15.3"})
    with urllib.request.urlopen(req, timeout=timeout) as response:
        return json.loads(response.read().decode("utf-8")), utc_now()


def pick_candidates(report, dex_limit=8, cex_limit=8):
    selected, seen = [], set()
    boards = ("execution_candidate_shortlist", "most_actionable_liquidity_screen",
              "top_24h_gainers", "top_24h_movers", "high_risk_moonshot_scouts")
    for board in boards:
        rows = report.get(board) or []
        for row in rows:
            if not isinstance(row, dict) or row.get("market_type") not in ("dex_pool", "cex_spot"):
                continue
            kind = row.get("market_type")
            ident = str(row.get("identity") or "").lower()
            if not ident:
                ident = "%s:%s:%s" % (kind, row.get("chain") or row.get("venue"), row.get("contract_address") or row.get("pair"))
            if ident in seen:
                continue
            seen.add(ident)
            selected.append(row)
    dex = [r for r in selected if r.get("market_type") == "dex_pool"]
    cex = [r for r in selected if r.get("market_type") == "cex_spot"]
    sort_key = lambda r: (num(r.get("rank_score")) or 0, num(r.get("change_24h_pct")) or -1e9,
                          num(r.get("volume_24h_usd")) or 0)
    dex.sort(key=sort_key, reverse=True)
    cex.sort(key=sort_key, reverse=True)
    # Keep market types separate; DEX gets first pass priority by design.
    return dex[:max(0, dex_limit)] + cex[:max(0, cex_limit)]


def derive_single_target(candles, current_price):
    """Choose the nearest 7d swing resistance; otherwise use a candle-derived range projection."""
    bars = sorted((x for x in candles if all(num(x.get(k)) is not None for k in ("h", "l", "c", "t"))),
                  key=lambda x: x["t"])
    if current_price is None or current_price <= 0 or len(bars) < 20:
        return None, "UNVERIFIED", "Insufficient completed OHLCV candles to derive one target."
    highs = [float(x["h"]) for x in bars]
    lows = [float(x["l"]) for x in bars]
    pivots = []
    for i in range(2, len(bars) - 2):
        h = highs[i]
        if h > current_price * 1.005 and h >= max(highs[i-2:i]) and h > max(highs[i+1:i+3]):
            pivots.append(h)
    if pivots:
        level = min(pivots)
        target = level * 0.9975  # aim just below the nearest observed overhead swing high
        if target > current_price:
            return round(target, 12), "7D_SWING_RESISTANCE", "Single take-profit set 0.25% below the nearest confirmed 1h swing high in the available 7d candles."
    last24 = bars[-24:]
    hi24 = max(x["h"] for x in last24)
    if hi24 > current_price * 1.01:
        return round(hi24 * 0.9975, 12), "24H_RANGE_HIGH", "Single take-profit set 0.25% below the observed 24h candle high."
    tr = []
    for prev, cur in zip(bars[:-1], bars[1:]):
        tr.append(max(cur["h"] - cur["l"], abs(cur["h"] - prev["c"]), abs(cur["l"] - prev["c"])))
    atr = sum(tr[-14:]) / min(14, len(tr)) if tr else 0
    range24 = hi24 - min(x["l"] for x in last24)
    projection = max(1.5 * atr, 0.5 * range24, current_price * 0.03)
    target = current_price + projection
    if math.isfinite(target) and target > current_price:
        return round(target, 12), "ATR_RANGE_PROJECTION", "No overhead swing high was found; single take-profit is a 24h volatility projection from 1h ATR/range, not a resistance level or calibrated probability."
    return None, "UNVERIFIED", "Could not derive a positive target from the candle history."


def candle_stats(candles, current_price):
    bars = sorted((x for x in candles if all(num(x.get(k)) is not None for k in ("o", "h", "l", "c", "qv", "t"))), key=lambda x: x["t"])
    if len(bars) < 8:
        return {}
    closes = [float(x["c"]) for x in bars]
    volumes = [float(x["qv"]) for x in bars]
    last = bars[-1]
    def ret_back(n):
        if len(closes) <= n or closes[-n-1] <= 0:
            return None
        return (current_price / closes[-n-1] - 1.0) * 100.0
    out = {"1h": ret_back(1), "4h": ret_back(4), "7d": ret_back(min(167, len(closes)-1))}
    one_hour_ratio = None
    if len(volumes) >= 25 and statistics_median(volumes[:-1]) > 0:
        one_hour_ratio = volumes[-1] / statistics_median(volumes[:-1])
    four_hour_ratio = None
    if len(volumes) >= 28:
        recent4 = sum(volumes[-4:])
        hist4 = [sum(volumes[i:i+4]) for i in range(0, len(volumes)-8, 4)]
        med4 = statistics_median(hist4) if hist4 else 0
        if med4 > 0:
            four_hour_ratio = recent4 / med4
    recent24 = bars[-24:]
    high24 = max(x["h"] for x in recent24)
    out["distance_to_24h_high_pct"] = max(0.0, (high24 / current_price - 1.0) * 100.0) if current_price > 0 else None
    lows = [x["l"] for x in bars[-6:]]
    out["higher_lows"] = len(lows) >= 4 and lows[-1] > lows[-3] and lows[-2] > lows[-4]
    out["fresh_impulse"] = bool(closes[-1] > closes[-2] and volumes[-1] >= (statistics_median(volumes[-25:-1]) if len(volumes) >= 25 else 0))
    out["volume_ratios"] = {"15m": None, "1h": one_hour_ratio, "4h": four_hour_ratio}
    out["candles"] = bars
    return out


def statistics_median(values):
    vals = sorted(float(x) for x in values if num(x) is not None)
    if not vals:
        return 0.0
    n = len(vals)
    return vals[n // 2] if n % 2 else (vals[n // 2 - 1] + vals[n // 2]) / 2.0


class GeckoThrottle:
    def __init__(self, interval=12.0):
        self.interval = interval
        self.last = 0.0

    def get(self, url, timeout=10):
        if self.last:
            wait = self.interval - (time.monotonic() - self.last)
            if wait > 0:
                time.sleep(wait)
        self.last = time.monotonic()
        return get_json(url, timeout)


def audit_indexes(report):
    post = report.get("post_scan_audit") or {}
    cvd = {}
    for item in ((post.get("gecko_spot_cvd_audit") or {}).get("audited") or []):
        cvd[(str(item.get("chain") or "").lower(), str(item.get("contract_address") or "").lower())] = item
    books = {}
    for item in ((post.get("cex_orderbook_audit") or {}).get("book_snapshots") or []):
        books[(str(item.get("identity") or "").lower(), str(item.get("venue") or "").lower())] = item
    security = {}
    for item in ((post.get("goplus_security_audit") or {}).get("audited") or []):
        security[(str(item.get("chain") or "").lower(), str(item.get("contract_address") or "").lower())] = item
    routes = {}
    for audit_key in ("dex_router_quote_audit", "solana_router_quote_audit"):
        for item in ((post.get(audit_key) or {}).get("quotes") or []):
            routes[(str(item.get("chain") or "").lower(), str(item.get("contract_address") or "").lower())] = item
    return cvd, books, security, routes


def gecko_network(chain):
    return GECKO_ALIASES.get(str(chain or "").lower(), str(chain or "").lower())


def fetch_dex_market(row, throttle, timeout=10):
    network = gecko_network(row.get("chain"))
    pool = str(row.get("pool_address") or "").strip()
    if not network or not pool:
        return None, [], None, "pool or network identity missing"
    pool_url = "%s/networks/%s/pools/%s?include=base_token,quote_token" % (
        GECKO, urllib.parse.quote(network, safe=""), urllib.parse.quote(pool, safe=""))
    try:
        payload, price_ts = throttle.get(pool_url, timeout)
        attrs = ((payload.get("data") or {}).get("attributes") or {}) if isinstance(payload, dict) else {}
        price = num(attrs.get("base_token_price_usd"))
        price_url = pool_url
    except Exception as exc:
        price, price_ts, price_url = None, None, pool_url
        price_error = "%s: %s" % (type(exc).__name__, exc)
    else:
        price_error = None
    params = urllib.parse.urlencode({"aggregate": 1, "limit": 168, "currency": "usd", "token": "base"})
    candle_url = "%s/networks/%s/pools/%s/ohlcv/hour?%s" % (
        GECKO, urllib.parse.quote(network, safe=""), urllib.parse.quote(pool, safe=""), params)
    try:
        candle_payload, candle_ts = throttle.get(candle_url, timeout)
        raw = (((candle_payload.get("data") or {}).get("attributes") or {}).get("ohlcv_list") or [])
        candles = [{"t": int(x[0]), "o": float(x[1]), "h": float(x[2]), "l": float(x[3]),
                   "c": float(x[4]), "qv": float(x[5])} for x in raw if isinstance(x, list) and len(x) >= 6]
    except Exception as exc:
        candles, candle_ts = [], None
        candle_error = "%s: %s" % (type(exc).__name__, exc)
    else:
        candle_error = None
    return price, candles, {"price_url": price_url, "price_timestamp_utc": price_ts,
                            "candle_url": candle_url, "candle_timestamp_utc": candle_ts,
                            "price_error": price_error, "candle_error": candle_error}, None


def make_candidate(row, scan_ts, cvd_index, books_index, security_index, routes_index,
                   gecko_throttle, cex_fx, timeout=10):
    kind = row.get("market_type")
    chain = str(row.get("chain") or "").lower() if kind == "dex_pool" else None
    contract = str(row.get("contract_address") or "")
    ident = str(row.get("identity") or "")
    price = num(row.get("price_usd"))
    # Never manufacture freshness from scan_start; missing retrieval timestamps remain missing.
    price_ts = row.get("retrieved_utc")
    price_source = row.get("source") or "scanner snapshot"
    price_url = row.get("source_url") or row.get("pair_url")
    candles, candle_url, candle_ts = [], None, None
    price_refresh_note = None
    book = None
    cvd_item = cvd_index.get((chain or "", contract.lower())) if kind == "dex_pool" else None
    security_item = security_index.get((chain or "", contract.lower())) if kind == "dex_pool" else None
    route_item = routes_index.get((chain or "", contract.lower())) if kind == "dex_pool" else None
    book_item = None
    if kind == "dex_pool":
        refreshed, candles, meta, error = fetch_dex_market(row, gecko_throttle, timeout)
        if refreshed is not None and refreshed > 0:
            price, price_ts, price_source, price_url = refreshed, meta.get("price_timestamp_utc"), "GeckoTerminal pool snapshot", meta.get("price_url")
        candle_url = (meta or {}).get("candle_url")
        candle_ts = (meta or {}).get("candle_timestamp_utc")
        if not candles:
            price_refresh_note = error or (meta or {}).get("candle_error") or "No OHLCV candles returned"
    else:
        venue_name = str(row.get("venue") or ((row.get("venues") or [None])[0]) or "").lower()
        adapter = venues.VENUES.get(venue_name)
        if adapter:
            symbol = adapter.pair_to_symbol(str(row.get("asset") or row.get("symbol") or "").upper())
            try:
                candles, candle_url = adapter.candles(cex_fx, symbol, "1h", limit=168)
                candle_ts = utc_now()
            except Exception as exc:
                candles = []
                price_refresh_note = "%s: %s" % (type(exc).__name__, exc)
            book_item = books_index.get((ident.lower(), venue_name))
            sim = (book_item or {}).get("simulation") or {}
            if sim.get("mid_price") is not None:
                price = num(sim.get("mid_price"))
                price_ts = (book_item or {}).get("retrieved_utc") or utc_now()
                price_source = "CEX order-book midpoint snapshot"
                price_url = (book_item or {}).get("url")
    stats = candle_stats(candles, price) if candles and price else {}
    if not stats:
        price_refresh_note = price_refresh_note or "Insufficient 1h candle history"
    target, target_method, target_note = derive_single_target(candles, price) if stats else (None, "UNVERIFIED", "Candle history unavailable.")
    scan_return24 = num(row.get("change_24h_pct"))
    ret24 = (price / stats["candles"][-25]["c"] - 1) * 100 if stats and len(stats["candles"]) >= 25 and stats["candles"][-25]["c"] > 0 else scan_return24
    ret1 = stats.get("1h") if stats else num(row.get("change_1h_pct"))
    ret4 = stats.get("4h") if stats else None
    ret7 = stats.get("7d") if stats else None
    volume_ratios = stats.get("volume_ratios") if stats else {"15m": None, "1h": None, "4h": None}
    cvd1 = ((cvd_item or {}).get("cvd_by_window") or {}).get("1h") or {}
    cvd6 = ((cvd_item or {}).get("cvd_by_window") or {}).get("6h") or {}
    cvd_checked = bool(cvd_item and cvd_item.get("status") == "SAMPLED_CVD_AVAILABLE" and cvd1.get("valid_trades_sampled", 0) > 0)
    cvd_ts = (cvd_item or {}).get("last_trade_utc")
    buyer_share = None
    cvd_ratio = num(cvd1.get("cvd_ratio_pct"))
    quote_turnover_1h = None
    if cvd_checked:
        total_flow = num(cvd1.get("buy_volume_usd")) + num(cvd1.get("sell_volume_usd"))
        quote_turnover_1h = total_flow
        if total_flow > 0:
            buyer_share = num(cvd1.get("buy_volume_usd")) / total_flow * 100.0
    book_sim = ((book_item or {}).get("simulation") or {})
    depth = book_sim.get("depth_within_2pct_usd") or {}
    spread = num(book_sim.get("spread_bps"))
    bid_depth = num(depth.get("bids"))
    ask_depth = num(depth.get("asks"))
    order_book_verified = bool(book_item and book_item.get("status") == "FULL_ROUND_TRIP_DEPTH_AVAILABLE")
    order_book_ts = (book_item or {}).get("retrieved_utc")
    safety_status = "UNVERIFIED"
    safety_checked = False
    hard_fail = False
    if security_item:
        audit = security_item.get("audit") or {}
        flags = audit.get("risk_flags") or []
        safety_checked = security_item.get("status") in ("FLAGGED_REVIEW", "PROVIDER_CHECK_RETURNED_REVIEW_REQUIRED")
        hard_fail = any(x in flags for x in ("HONEYPOT", "CANNOT_BUY", "CANNOT_SELL_ALL"))
        safety_status = "FAIL" if hard_fail else "UNVERIFIED"
    route_ts = (route_item or {}).get("timestamp_utc")
    firm_or_route_ok = bool(route_item and (
        route_item.get("status") == "BUY_AND_SELL_FIRM_QUOTES_RETURNED" or
        (str(route_item.get("provider", "")).lower().startswith("jupiter") and route_item.get("status") == "BUY_AND_SELL_ROUTES_RETURNED")))
    buy_q = (route_item or {}).get("buy_quote") or {}
    sell_q = (route_item or {}).get("sell_quote") or {}
    input_usd = num((route_item or {}).get("notional_usd"))
    token_out = num(buy_q.get("buy_amount_token_raw") or buy_q.get("output_amount_token_raw"))
    token_in = num(sell_q.get("sell_amount_token_raw") or sell_q.get("input_amount_token_raw"))
    candidate = {
        "asset": row.get("asset") or row.get("symbol"), "symbol": row.get("symbol"),
        "pair": row.get("pair"), "venue": row.get("venue") or row.get("chain"),
        "market_type": kind, "chain": chain, "contract_address": contract,
        "pool_address": row.get("pool_address"), "pair_url": row.get("pair_url"),
        "identity": ident, "source": price_source, "source_url": price_url,
        "price": price, "data_timestamp_utc": price_ts,
        "spot_available": kind == "cex_spot", "dex_available": kind == "dex_pool",
        "returns_pct": {"1h": ret1, "4h": ret4, "24h": ret24, "7d": ret7},
        "relative_strength_pct": {}, "volume_ratios": volume_ratios,
        "spot_buyer_share_pct": buyer_share,
        "spot_cvd_change_1h_usd": num(cvd1.get("cvd_usd")) if cvd_checked else None,
        "spot_cvd_ratio_1h_pct": cvd_ratio if cvd_checked else None,
        "spot_quote_volume_1h_usd": quote_turnover_1h,
        "spot_cvd_checked": cvd_checked, "spot_cvd_method": "trade_level" if cvd_checked else "UNVERIFIED",
        "spot_cvd_timestamp_utc": cvd_ts,
        "distance_to_24h_high_pct": stats.get("distance_to_24h_high_pct") if stats else None,
        "higher_lows": stats.get("higher_lows") if stats else None,
        "fresh_impulse": stats.get("fresh_impulse") if stats else None,
        "catalyst_checked": False,
        "quote_turnover_24h_usd": num(row.get("volume_24h_usd")),
        "spread_bps": spread, "bid_depth_2pct_usd": bid_depth, "ask_depth_2pct_usd": ask_depth,
        "order_notional_usd": 100.0,
        "order_book_verified": order_book_verified, "order_book_timestamp_utc": order_book_ts,
        "derivatives_checked": False, "derivatives_audit_status": "UNVERIFIED",
        "safety_checked": safety_checked, "safety_status": safety_status, "hard_safety_fail": hard_fail,
        "target_price": target, "target_price_source": target_method, "target_price_note": target_note,
        "dex_buy_quote_available": bool(firm_or_route_ok), "dex_sell_quote_available": bool(firm_or_route_ok),
        "dex_quote_timestamp_utc": route_ts, "dex_buy_quote_input_usd": input_usd,
        "dex_buy_base_output_amount": token_out, "dex_sell_base_input_amount": token_in,
        "field_evidence": {
            "price": {"source": price_source, "url": price_url, "timestamp_utc": price_ts},
            "volume_1h": {"source": "1h OHLCV", "url": candle_url, "timestamp_utc": candle_ts} if candle_url and candle_ts else None,
            "spot_trades": {"source": "GeckoTerminal recent trades sample", "url": "https://api.geckoterminal.com/api/v2/networks/%s/pools/%s/trades" % (chain, row.get("pool_address")), "timestamp_utc": cvd_ts} if cvd_checked else None,
            "spot_cvd": {"source": "GeckoTerminal sampled DEX swaps", "url": "https://api.geckoterminal.com/api/v2/networks/%s/pools/%s/trades" % (chain, row.get("pool_address")), "timestamp_utc": cvd_ts} if cvd_checked else None,
            "order_book": {"source": "CEX order book snapshot", "url": (book_item or {}).get("url"), "timestamp_utc": order_book_ts} if book_item and order_book_ts else None,
            "safety": {"source": "GoPlus", "url": None, "timestamp_utc": security_item.get("retrieved_utc")} if security_item else None,
            "single_take_profit": {"source": "GeckoTerminal / CEX historical 1h OHLCV", "url": candle_url, "timestamp_utc": candle_ts, "method": target_method} if target is not None and candle_ts else None,
            "route_quotes": {"source": (route_item or {}).get("provider"), "url": None, "timestamp_utc": route_ts} if route_item and route_ts else None,
        },
        "high_risk_scout": bool(row.get("risk_tier") in ("DUST / EXTREME EXECUTION RISK", "ULTRA-THIN MICROCAP", "HIGH-RISK MICROCAP")),
        "source_refs": {"ticker": price_url, "candles": candle_url, "pool": row.get("pair_url")},
        "_scan_row": row, "_candles_count": len(candles), "_candle_url": candle_url,
        "_target_note": target_note, "_price_refresh_note": price_refresh_note,
    }
    return candidate


def render_markdown(doc, report):
    top = doc.get("top_rocket_pick") or {}
    raw = doc.get("raw_upside_leader") or {}
    raw_rows = report.get("top_24h_gainers") or []
    raw_asset = raw_rows[0] if raw_rows and isinstance(raw_rows[0], dict) else {}
    fmt = lambda x: "UNVERIFIED" if num(x) is None else ("$" + format(float(x), ".12g"))
    scan_start = doc.get("forecast_window_start_utc")
    forecast_end = doc.get("forecast_window_end_utc")
    trade = top.get("trade_plan") or {}
    plan_entry = trade.get("entry_price")
    target = trade.get("single_take_profit")
    candidate = top.get("_market_metadata") or {}
    lines = ["## Forward 24-hour rocket forecast", "",
             "**Forecast window:** %s → %s  |  **Data snapshot:** %s  |  **Coverage:** %s" % (
                 scan_start, forecast_end, doc.get("as_of_utc"), report.get("coverage", {}).get("status")),
             "**Collection order:** %s" % (" → ".join(report.get("coverage", {}).get("scan_order") or ["DEX sources before CEX, then aggregators"])), "",
             "### Trailing raw 24h champion (discovery only)", "",
             "**%s** (%s) — %s | current scan snapshot %s" % (
                 raw_asset.get("asset") or raw.get("asset") or "No qualifying row",
                 raw_asset.get("symbol") or raw.get("pair") or "—",
                 (("%+.2f%%" % num(raw_asset.get("change_24h_pct"))) if num(raw_asset.get("change_24h_pct")) is not None else "UNVERIFIED") if raw_asset else "—",
                 fmt(raw_asset.get("price_usd")) if raw_asset else "UNVERIFIED"), "",
             "### Forward 24h Top Pick", "",
             "**%s** — %s" % (top.get("asset", "UNAVAILABLE"), top.get("entry_decision", "UNVERIFIED")), "",
             "| Field | Value |", "|---|---|",
             "| Current price (USD) | %s |" % fmt(top.get("price")),
             "| Price source timestamp (UTC) | %s |" % (top.get("data_timestamp_utc") or "UNVERIFIED"),
             "| Pair | %s |" % (top.get("pair") or "UNVERIFIED"),
             "| Venue / chain | %s |" % (top.get("venue") or top.get("chain") or "UNVERIFIED"),
             "| Pool / pair address (copy) | `%s` |" % (top.get("pool_address") or "N/A for CEX"),
             "| Token contract / mint (copy) | `%s` |" % (top.get("contract_address") or "UNVERIFIED"),
             "| Pair page | %s |" % (top.get("pair_url") or "UNVERIFIED"),
             "| Entry price | %s |" % (fmt(plan_entry) if plan_entry is not None else "UNVERIFIED — no verified route"),
             "| Single take-profit | %s |" % (fmt(target) if target is not None else "UNVERIFIED — OHLCV target unavailable"),
             "| Take-profit method | %s |" % (top.get("target_price_source") or "UNVERIFIED"),
             "| 24h time stop | %s |" % (trade.get("time_stop_24h") or forecast_end or "UNVERIFIED"),
             "| Forecast score | %s / 100 (heuristic, not probability) |" % top.get("forecast_score"),
             "| Relative confidence | %s |" % top.get("relative_confidence", "UNVERIFIED"), "",
             "**Why it ranks:**"]
    for detail in (top.get("factor_details") or []):
        if detail.get("supported"):
            lines.append("- %s: %s" % (detail.get("factor"), detail.get("note")))
    lines += ["", "**Verification gaps:**"]
    for item in (top.get("entry_blockers") or []):
        lines.append("- " + item)
    if not top.get("entry_blockers"):
        lines.append("- None recorded by this heuristic gate; still not a fill guarantee.")
    if top.get("risk_flags"):
        lines += ["", "**Risk flags:**"]
        lines.extend("- " + x for x in top.get("risk_flags", [])[:12])
    lines += ["", "### Forward-24h ranking (sampled accessible universe)", "",
              "| Rank | Asset | Market | 24h observed move | Current price | Single TP | Status | Pair address | Token contract |",
              "|---:|---|---|---:|---:|---:|---|---|---|"]
    for item in doc.get("candidates", [])[:25]:
        md = next((m for m in report.get("candidates", []) if m.get("identity") == item.get("identity")), {})
        lines.append("| %s | %s | %s | %s | %s | %s | %s | `%s` | `%s` |" % (
            item.get("forecast_rank"), item.get("asset"), item.get("market_type"),
            ("n/a" if num((item.get("returns_pct") or {}).get("24h")) is None else "%+.2f%%" % num((item.get("returns_pct") or {}).get("24h"))),
            fmt(item.get("price")), fmt((item.get("trade_plan") or {}).get("single_take_profit")),
            item.get("entry_decision"), md.get("pool_address") or "N/A", md.get("contract_address") or "—"))
    lines += ["", "**Important:** the forecast is a ranking heuristic, not a calibrated probability or a guarantee that this asset will be the actual best gainer. The trailing raw 24h champion and forward forecast are separate. DEX trade CVD remains capped to one pool/300 sampled trades; missing CEX CVD, derivatives and full safety evidence remain unverified.", ""]
    return "\n".join(lines)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--report", default="rocket-run/rocket-hunt.json")
    parser.add_argument("--markdown", default="rocket-run/rocket-hunt.md")
    parser.add_argument("--out", default="rocket-run/forward-24h-rocket.json")
    parser.add_argument("--dex-limit", type=int, default=8)
    parser.add_argument("--cex-limit", type=int, default=8)
    parser.add_argument("--timeout", type=int, default=10)
    parser.add_argument("--gecko-interval", type=float, default=12.0)
    args = parser.parse_args(argv)
    if args.dex_limit < 0 or args.cex_limit < 0 or args.timeout <= 0 or args.gecko_interval < 0:
        parser.error("limits must be non-negative and timeout positive")
    try:
        report_path = Path(args.report)
        report = json.loads(report_path.read_text(encoding="utf-8"))
        scan_start = report.get("scan_start_utc") or report.get("created_utc")
        if parse_dt(scan_start) is None:
            raise ValueError("scanner output is missing a valid scan_start_utc")
        cvd_idx, books_idx, security_idx, routes_idx = audit_indexes(report)
        selected = pick_candidates(report, args.dex_limit, args.cex_limit)
        throttle = GeckoThrottle(args.gecko_interval)
        cex_fx = venues.Fetcher(timeout=args.timeout, retries=2, pause=0)
        candidates = [make_candidate(row, scan_start, cvd_idx, books_idx, security_idx, routes_idx,
                                     throttle, cex_fx, args.timeout) for row in selected]
        # The forward winner must have a timestamped current price and a candle-backed
        # single target. Keep non-qualifying discoveries in the raw scan boards, but
        # do not let a no-candle mark win a forward trade-plan ranking.
        forecast_candidates = [c for c in candidates if c.get("market_type") == "dex_pool" and
                               c.get("pool_address") and c.get("contract_address") and
                               num(c.get("price")) and num(c.get("target_price")) and
                               num(c.get("target_price")) > num(c.get("price")) and
                               c.get("_candles_count", 0) >= 20]
        if not forecast_candidates:
            # Keep one DEX Top Rocket visible even when OHLCV is unavailable, but
            # do not invent a target or executable entry. The three-field plan
            # remains explicit and uses UNVERIFIED for the unsupported values.
            now = utc_now()
            scan_start_dt = parse_dt(scan_start)
            forecast_end = (scan_start_dt + timedelta(hours=24)).replace(microsecond=0).isoformat().replace("+00:00", "Z")
            raw_rows = report.get("top_24h_gainers") or []
            raw_top = raw_rows[0] if raw_rows else None
            fallback_pool = [c for c in candidates if c.get("market_type") == "dex_pool" and
                             c.get("pool_address") and c.get("contract_address")]
            fallback_pool.sort(key=lambda c: (num((c.get("_scan_row") or {}).get("rank_score")) or 0,
                                              num((c.get("_scan_row") or {}).get("change_24h_pct")) or -1e9), reverse=True)
            fallback = fallback_pool[0] if fallback_pool else None
            top_pick = None
            if fallback:
                top_pick = {"asset": fallback.get("asset"), "pair": fallback.get("pair"),
                            "venue": fallback.get("venue"), "chain": fallback.get("chain"),
                            "market_type": "dex_pool", "identity": fallback.get("identity"),
                            "price": fallback.get("price"), "data_timestamp_utc": fallback.get("data_timestamp_utc"),
                            "pool_address": fallback.get("pool_address"), "contract_address": fallback.get("contract_address"),
                            "pair_url": fallback.get("pair_url"), "entry_decision": "TOP ROCKET — EXECUTION UNVERIFIED",
                            "entry_blockers": ["No sufficient fresh hourly OHLCV was available to derive a source-backed single take-profit.",
                                               "Fresh executable DEX buy AND sell router quotes are not verified."],
                            "risk_flags": ["Forward-24h selection is a heuristic, not a calibrated prediction."],
                            "forecast_score": None, "relative_confidence": "UNVERIFIED",
                            "trade_plan": {"entry_price": None, "single_take_profit": None, "time_stop_24h": forecast_end},
                            "target_price_source": "UNVERIFIED"}
            no_pick = {"schema": "crypto-prebreakout.forward-24h-rocket.v1", "status": "TOP_ROCKET_EXECUTION_UNVERIFIED" if top_pick else "NO_DEX_POOL_WITH_COPYABLE_IDENTITY",
                       "scan_start_utc": scan_start, "forecast_window_start_utc": scan_start,
                       "forecast_window_end_utc": forecast_end, "as_of_utc": now,
                       "universe": "SAMPLED ACCESSIBLE DEX DISCOVERY; 24 configured networks attempted, seven CEX boards run separately",
                       "reason": "No DEX candidate had all of: a copyable pool address, token contract, fresh price, at least 20 hourly OHLCV candles, and a single candle-derived target above current price.",
                       "raw_trailing_24h_champion": raw_top, "top_rocket_pick": top_pick,
                       "trade_plan": (top_pick or {}).get("trade_plan") or {"entry_price": None, "single_take_profit": None, "time_stop_24h": forecast_end},
                       "data_collection": {"selected_dex_candidates": sum(1 for x in candidates if x.get("market_type") == "dex_pool"),
                                           "selected_cex_candidates": sum(1 for x in candidates if x.get("market_type") == "cex_spot"),
                                           "forecast_eligible_candidates": 0,
                                           "ohlcv_candidates": sum(1 for x in candidates if x.get("_candles_count", 0) >= 20)}}
            Path(args.out).parent.mkdir(parents=True, exist_ok=True)
            Path(args.out).write_text(json.dumps(no_pick, indent=2, sort_keys=True), encoding="utf-8")
            raw_change = num((raw_top or {}).get("change_24h_pct"))
            raw_price = num((raw_top or {}).get("price_usd"))
            lines = ["## Forward 24-hour rocket forecast", "",
                     "**Status:** %s" % ("TOP ROCKET — EXECUTION UNVERIFIED" if top_pick else "NO DEX POOL WITH COPYABLE IDENTITY"), "",
                     "**Forecast window:** %s → %s | **Data snapshot:** %s" % (scan_start, forecast_end, now), "",
                     "No DEX candidate met every requirement for a fully source-backed forward trade plan: a copyable pool address, token contract, fresh price, sufficient hourly candle history and one candle-derived take-profit above current price.", "",
                     "No entry or target was invented. The raw trailing 24h champion is shown separately and is not the forward forecast.", "",
                     "**Trailing raw 24h champion:** %s (%s), observed move %s, price %s" % (
                         (raw_top or {}).get("asset", "None"), (raw_top or {}).get("symbol", "—"),
                         ("%+.2f%%" % raw_change) if raw_change is not None else "UNVERIFIED",
                         ("$" + format(raw_price, ".12g")) if raw_price is not None else "UNVERIFIED")]
            if top_pick:
                lines += ["", "### Forward 24h Top Pick", "",
                          "**%s** — TOP ROCKET / EXECUTION UNVERIFIED" % top_pick.get("asset"), "",
                          "| Field | Value |", "|---|---|",
                          "| Current price (USD) | %s |" % (("$" + format(num(top_pick.get("price")), ".12g")) if num(top_pick.get("price")) is not None else "UNVERIFIED"),
                          "| Price source timestamp (UTC) | %s |" % (top_pick.get("data_timestamp_utc") or "UNVERIFIED"),
                          "| Pair | %s |" % (top_pick.get("pair") or "UNVERIFIED"),
                          "| Pool / pair address (copy) | `%s` |" % top_pick.get("pool_address"),
                          "| Token contract / mint (copy) | `%s` |" % top_pick.get("contract_address"),
                          "| Pair page | %s |" % (top_pick.get("pair_url") or "UNVERIFIED"),
                          "| Entry price | UNVERIFIED — no executable route |",
                          "| Single take-profit | UNVERIFIED — OHLCV target unavailable |",
                          "| Time stop (24h) | %s |" % forecast_end]
            lines += ["", "CEX discovery remains in the broad mover report. The final Top Rocket is DEX-only so the on-chain pool address and token contract are directly copyable."]
            with Path(args.markdown).open("a", encoding="utf-8") as fh:
                fh.write("\n\n" + "\n".join(lines) + "\n")
            print("Forward 24h Top Rocket: %s — no source-backed TP was available." % (top_pick.get("asset") if top_pick else "NO DEX PICK"), flush=True)
            print("Forward candidates: discovered DEX=%d CEX=%d; OHLCV=%d; forecast-eligible=0" % (
                no_pick["data_collection"]["selected_dex_candidates"], no_pick["data_collection"]["selected_cex_candidates"],
                no_pick["data_collection"]["ohlcv_candidates"]), flush=True)
            return 0
        snapshot = utc_now()
        forecast_input = {"as_of_utc": snapshot, "forecast_window_start_utc": scan_start,
                          "forecast_horizon_hours": 24, "universe": "SAMPLED ACCESSIBLE WEB3: GeckoTerminal/DexScreener DEX + seven CEX spot adapters + aggregators",
                          "spot_only": True, "require_field_provenance": True,
                          "require_chase_diagnostics": False, "candidates": forecast_candidates,
                          "market_context": {"label": "UNVERIFIED — market-regime enrichment not attached"}}
        doc = next_day_forecast.rank_document(forecast_input, max_age_minutes=45)
        meta = {str(x.get("identity")): x for x in candidates}
        for item in doc.get("candidates", []):
            item_meta = meta.get(str(item.get("identity")), {})
            item.update({"pool_address": item_meta.get("pool_address"), "pair_url": item_meta.get("pair_url"),
                         "data_timestamp_utc": item_meta.get("data_timestamp_utc"),
                         "target_price_source": item_meta.get("target_price_source"),
                         "target_price_note": item_meta.get("target_price_note")})
        top = doc.get("top_rocket_pick") or {}
        top_meta = meta.get(str(top.get("identity")), {})
        top.update({"pool_address": top_meta.get("pool_address"), "pair_url": top_meta.get("pair_url"),
                    "data_timestamp_utc": top_meta.get("data_timestamp_utc"),
                    "target_price_source": top_meta.get("target_price_source"),
                    "target_price_note": top_meta.get("target_price_note")})
        doc["top_rocket_pick"] = top
        doc["scan_start_utc"] = scan_start
        doc["trailing_raw_24h_champion"] = (report.get("top_24h_gainers") or [None])[0]
        doc["forecast_generation_utc"] = snapshot
        doc["data_collection"] = {"selected_dex_candidates": sum(1 for x in candidates if x.get("market_type") == "dex_pool"),
                                  "selected_cex_candidates": sum(1 for x in candidates if x.get("market_type") == "cex_spot"),
                                  "forecast_eligible_candidates": len(forecast_candidates),
                                  "ohlcv_candidates": sum(1 for x in candidates if x.get("_candles_count", 0) >= 20),
                                  "target_method_counts": {method: sum(1 for x in candidates if x.get("target_price_source") == method)
                                                           for method in sorted(set(x.get("target_price_source") for x in candidates))}}
        Path(args.out).parent.mkdir(parents=True, exist_ok=True)
        Path(args.out).write_text(json.dumps(doc, indent=2, sort_keys=True), encoding="utf-8")
        md = render_markdown(doc, report)
        Path(args.markdown).write_text(Path(args.markdown).read_text(encoding="utf-8") + "\n\n" + md + "\n", encoding="utf-8")
        print("Forward 24h Top Rocket: %s | status=%s | current=%s | single TP=%s | time stop=%s" % (
            top.get("asset"), top.get("entry_decision"), top.get("price"),
            (top.get("trade_plan") or {}).get("single_take_profit"), (top.get("trade_plan") or {}).get("time_stop_24h")), flush=True)
        print("Forward candidates: discovered DEX=%d CEX=%d; forecast-eligible=%d; OHLCV=%d" % (
            doc["data_collection"]["selected_dex_candidates"], doc["data_collection"]["selected_cex_candidates"],
            doc["data_collection"]["forecast_eligible_candidates"], doc["data_collection"]["ohlcv_candidates"]), flush=True)
        return 0
    except Exception as exc:
        print("Forward 24h report failed: %s: %s" % (type(exc).__name__, exc), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
